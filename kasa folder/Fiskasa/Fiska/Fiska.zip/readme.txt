Dokumentacija se nalazi na stranici:

http://www.dosprinter.net/Fiskalizacija,,

sifra ti je 17021